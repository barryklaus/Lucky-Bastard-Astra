'use strict';
(()=>{const P=LB.path,L=LB.line,E=LB.ellipse;
const heads=[
'M-32-42 Q-9-59 18-48 Q38-44 40-17 L37 12 Q32 34 8 39 Q-18 39-30 25 L-39 4 Q-43-20-32-42Z',
'M-34-44 Q-16-51 20-47 L35-35 36-5 40 20 Q31 31 7 32 L-24 30-36 17-39-13Z',
'M-25-53 Q3-64 25-48 L31-18 25 17 18 43 Q-2 51-23 34 L-29 3-31-25Z',
'M-43-36 Q-19-53 18-43 Q43-36 47-12 L44 14 Q30 35 4 31 L-32 26-46 8 Q-53-15-43-36Z',
'M-30-44 Q-2-60 24-43 L34-13 25 14 3 43 Q-3 48-10 38 L-31 15-36-12Z',
'M-25-48 Q1-59 23-45 L25-13 Q42 0 39 20 Q31 43 1 43 Q-33 42-40 22 Q-44 2-28-15Z',
'M-39-48 Q-8-66 25-47 Q44-35 39-10 L24 21 3 35-19 27-36 1Z',
'M-35-44 Q-8-60 25-44 L37-24 30 6 10 34 Q3 40-7 34 L-24 20-38-8Z',
'M-31-43 Q-12-58 21-44 L31-19 29 0 Q44 12 40 27 Q19 43-14 36 L-38 25-43 7-32-13Z',
'M-36-40 Q-19-60 10-51 Q31-49 37-26 L29-5 40 15 Q33 33 10 36 L-14 29-35 33-42 7-34-17Z'];
const hairs=[
'M-39-23 L-47-39-34-41-39-56-20-53-20-69-5-59 6-75 15-58 35-63 29-46 46-40 34-25 20-35 8-29-5-39-18-31-27-14Z',
'M-36-22 L-40-40-26-49-14-53 7-53 28-44 36-28 26-29 16-37 1-35-12-40-26-32-27-17Z',
'M-36-19 Q-55-44-34-57 Q-12-69 28-53 L47-51 34-44 50-40 27-33 Q-6-49-23-31 L-25-9Z',
'M-37-20 Q-53-25-44-38 Q-54-51-36-56 Q-39-71-23-66 Q-16-81-5-67 Q12-80 19-64 Q38-68 35-52 Q54-42 37-32 Q36-19 23-26 Q14-37 6-30 Q-9-44-20-28 Q-25-14-37-20Z',
'M-40-9 Q-63-12-53-30 Q-70-42-52-56 Q-60-76-38-77 Q-34-99-14-88 Q1-107 16-84 Q43-94 44-72 Q65-65 50-44 Q67-24 43-15 L26-25 Q31-44 11-43 Q-7-62-24-36 L-25-9Z',
'M-14-40 L-21-69-13-65-9-93-2-76 6-106 10-75 20-79 17-52 27-44 10-36Z',
'M-35-18 Q-48-45-21-55 Q9-69 29-47 L37-27 25-29 Q8-46-8-35 L-27-32-26-12Z',
'M-38-18 L-47-47-27-40-32-77-11-53-1-89 10-55 36-78 27-43 51-43 34-22 11-38-8-31-24-24-26-10Z',
'M-38-24 Q-43-62-13-61 Q11-72 34-47 L48-30 28-26 10-40-2-30-10-8-18 0-18-29Z',
'M-40 22 Q-57-12-38-48 Q-12-73 22-51 Q46-43 39-14 L37 29 21 24 22-15 Q7-37-4-42 Q-8-22-24-17 L-25 25Z',
'M-36-18 Q-43-44-25-51 Q-35-72-16-79 Q11-84 12-57 Q32-48 37-27 L23-26 7-38-14-32-26-17Z',
'M-35-20 L-38-28-33-35-28-30-29-19Z M29-20 L33-29 37-20 32-9Z',
'M-38-10 Q-44-31-30-42 L-18-45-21-29-29-25-28-6Z M20-40 L33-37 39-22 30-12 27-30Z',
'M-37-11 Q-46-44-27-52 L-11-62 3-53 17-59 33-43 39-24 24-23 12-35-5-33-19-19-26-8Z'];
LB.drawBackHair=function(c,a,t){if([6,9,13].includes(a.hair)){c.save();c.translate(0,-166);let sway=Math.sin(t*3)*4;P(c,`M-25-39 Q-60-25 ${-52+sway} 15 L${-60+sway} 49 -41 41 -32 49 -24 20 Q-17-6-25-39Z`,a.hairColor);P(c,`M-36-10 Q-44 18 ${-45+sway} 34`,null,LB.shade(a.hairColor,25),2);c.restore()}};
// Ear roots are placed inside each head contour. Size changes happen around the
// attachment, so larger ears cannot move away from a narrow head.
LB.faceEarAnchors=[[-38,38],[-38,36],[-28,28],[-47,46],[-34,30],[-36,33],[-35,33],[-34,32],[-37,30],[-39,33]];
LB.drawEars=function(c,a){
 const anchors=LB.faceEarAnchors[a.head],size=a.ears===1?1.35:a.ears===3?.7:1;
 for(let side=0;side<2;side++){
  c.save();c.translate(anchors[side],side?2:0);c.scale((side?1:-1)*size,size);
  P(c,a.ears===2?'M-7-12 Q2-16 21-26 L17-5 Q16 10 3 17 L-7 12 Q-10 1-7-12Z':'M-7-12 Q9-25 16-13 Q23 3 7 16 Q0 20-7 12 Q-10 1-7-12Z',side?a.skin:LB.shade(a.skin,-27),LB.ink,2.6);
  P(c,'M1-8 Q12-17 13-5 Q13 3 5 5 L2 10 M4-4 Q9-7 10-2',null,LB.shade(a.skin,-52),1.6);
  if(!side&&a.accessory===5)E(c,5,15,4.4,6,null,'#dcb75b',2.2);
  c.restore();
 }
};
LB.drawFace=function(c,a,expression='neutral',t=0,look=1,injury=0,headOnly=false){c.save();const skin=a.skin,shadow=LB.shade(skin,-27),hi=LB.shade(skin,22);let hurt=['hurt','shocked','scared','begging'].includes(expression),dead=['dead','unconscious'].includes(expression),angry=['angry','focused'].includes(expression),laugh=['laughing','victorious'].includes(expression),dizzy=expression==='dizzy',smug=expression==='smug';const blink=dead?1:Math.pow(Math.max(0,Math.cos(t*1.05+a.head*2)),55);LB.drawEars(c,a);P(c,heads[a.head],skin,LB.ink,3.3);P(c,'M-31 0 Q-30 18-12 22 Q9 31 31 16 L34 27 Q10 43-16 31 L-33 20Z',shadow,null);P(c,'M-24-35 Q-7-49 9-42 L-1-37-19-29Z',hi,null);P(c,'M-30 3 Q-22-4-17 3 M23 5 Q33-2 34 7',null,LB.shade(skin,-45),1.7);
// Nose bridge and asymmetrical eye sockets.
const eyeY=-18+(a.eyes===2?3:0);for(let side=-1;side<=1;side+=2){const x=side===-1?-16:17,y=eyeY+(side===1?3:0),wide=a.eyes===4?1.25:a.eyes===3?.72:1; c.save();c.translate(x,y);c.scale(wide,1);const h=dead?.6:hurt?10:Math.max(1,7*(1-blink));P(c,`M-12 0 Q-8 ${-h-5} 0 ${-h-3} Q10 ${-h-3} 12 0 Q8 ${h} 0 ${h+1} Q-10 ${h}-12 0Z`,'#f6eed7',LB.ink,2);if(!dead&&blink<.85){let px=look*3+Math.sin(t*.7+side)*.5;if(dizzy)px=Math.sin(t*8+side)*5;E(c,px,0,4.7,h*.7,a.eyeColor,LB.ink,1);E(c,px+1,0,1.9,h*.56,LB.ink);E(c,px+1,-2,1,1,'#fff7dc')}if(a.eyes===0||a.eyes===2||angry||smug){P(c,`M-12-1 Q-5-10 10-4 L12 0 ${angry?'-10 2':'-12-1'}Z`,shadow,LB.ink,1.8)}P(c,'M-10 9 Q0 13 9 8',null,LB.shade(skin,-40),1.4);let browY=hurt?-15:-12;P(c,`M-12 ${browY+((angry&&side<0)?-3:1)} Q0 ${browY-4} 12 ${browY+(angry?6:0)} L11 ${browY+4} Q-3 ${browY-1}-12 ${browY+4}Z`,a.hairColor,LB.ink,1.3);c.restore()}
const noses=['M2-21 Q-4-11 0-3 L13-1 Q18 7 7 9 L-6 5-8 1','M2-23 Q-4-9 7-4 Q23-2 15 10 L7 14 2 7-7 4','M1-15 Q-8-3-1 5 Q9 12 16 5 Q19-3 7-4','M0-23 L-3-7 26 1 Q29 8 17 10 L-4 5','M0-15 Q-12-3-10 5 Q-4 14 5 9 Q16 16 22 6 Q23-4 9-4','M0-20 Q-3-7 10-8 Q24-17 22-2 Q15 12 0 7 L-5 3','M2-22 L-6-11 5-8 1-3 15 0 Q20 9 10 10 L-7 5','M1-20 Q-5-10-2-5 Q-15 0-4 10 Q7 19 21 9 Q31-6 13-7'];P(c,noses[a.nose],skin,LB.ink,2.1);P(c,'M3 6 Q8 2 11 7',null,LB.shade(skin,-65),1.7);E(c,-4,5,2,1.1,shadow);
// Jaw, crooked lips, uneven teeth and tongue.
c.save();c.translate(0,hurt?4:0);let mouth=a.mouth,open=hurt||laugh||expression==='exhausted';if(dead){P(c,'M-13 19 Q1 13 14 20 L11 26-1 24Z','#6e3d36');P(c,'M1 23 Q12 20 17 25 L14 30 6 28Z','#c4776c',LB.ink,1.2)}else if(open){P(c,'M-17 13 Q1 6 21 13 Q25 35 6 36 Q-13 33-17 13Z','#562e30',LB.ink,2);P(c,'M-14 14 Q3 9 18 14 L16 21-10 22Z','#f2e6c9',LB.ink,1);L(c,[-3,13,-3,21,5,21,6,12],LB.ink,1);P(c,'M-5 29 Q3 23 11 29 L14 32 Q2 38-6 30Z','#ce786f',null)}else if(mouth===3||angry){P(c,'M-17 15 Q1 9 21 13 L18 25 Q0 29-16 23Z','#f5e9cc',LB.ink,2);L(c,[-10,14,-9,23,-1,24,-1,13,7,13,7,24,15,24,15,13],LB.ink,1);P(c,'M0 14 L7 13 7 20 0 21Z','#49312d',null)}else if(mouth===1){P(c,'M-15 16 Q0 11 19 14 L15 23-6 26Z','#643b35');P(c,'M-8 15 L7 14 7 24-6 25Z','#f6e9cb',LB.ink,1.2);L(c,[0,15,0,24],LB.ink,1)}else if(mouth===2){P(c,'M-17 17 Q0 29 21 14 L16 29-10 30Z',shadow);P(c,'M-9 26 L-7 19 4 22 5 28Z','#f2e3c3',LB.ink,1)}else{P(c,mouth===7?'M-16 24 Q0 10 21 22':mouth===6?'M0 17 Q11 13 9 20 L0 23':'M-18 16 Q-2 30 23 13',null,LB.ink,2.3);P(c,'M-4 29 Q5 32 12 27',null,shadow,1.6)}c.restore();
if(a.beard===1){for(let i=0;i<18;i++){let x=-25+(i*11%54),y=24+(i*7%11);L(c,[x,y,x+1,y+2],LB.shade(skin,-65),1)}}if(a.beard===2)P(c,'M-2 9 Q-11 6-19 15 L-12 19 1 15 Q13 21 22 13 L12 8 5 10Z',a.hairColor);if(a.beard===3)P(c,'M-9 29 Q3 33 14 28 L10 42 0 46-10 39Z',a.hairColor);if(a.beard===4)P(c,'M-33 4 L-25 11-20 25-9 28 1 23 14 27 26 12 32 7 32 31 16 46-6 49-30 32Z',a.hairColor);if(a.beard===5)P(c,'M-33-14 L-24-9-26 13-34 9Z M31-10 L25-9 25 12 33 6Z',a.hairColor);
if(a.details===0)for(let i=0;i<8;i++)E(c,(i<4?-25:23)+(i%4)*2.5,6+(i%2)*4,.8,.7,LB.shade(skin,-58));if(a.details===1)P(c,'M-24-32 L-16-2 M-23-22 L-17-24 M-20-12 L-14-14',null,LB.shade(skin,-60),1.4);if(a.details===2)E(c,27,15,2,1.7,LB.shade(skin,-80));if(a.details===3)P(c,'M-19-37 Q-4-41 13-35 M-17-31 Q0-35 17-30 M-26 15 L-21 18 M25 17 L29 22',null,shadow,1.3);if(a.details===4)P(c,'M-27-3 Q-16 5-5-2 M9 1 Q22 8 30 1',null,shadow,2.4);
P(c,hairs[a.hair],a.hairColor,LB.ink,2.8);if(a.hair!==11&&a.hair!==12){P(c,'M-28-42 Q-15-51-3-45 M4-48 Q14-48 22-40',null,LB.shade(a.hairColor,25),2);if([3,4].includes(a.hair))for(let i=0;i<5;i++)P(c,`M${-35+i*14} ${-48-(i%2)*13} q-7-8 1-11 q9 0 5 8`,null,LB.shade(a.hairColor,-15),1.5)}
if(a.accessory===1){P(c,'M-32-23 L-4-22-4-6-28-6Z M7-21 L33-19 31-3 7-4Z',null,'#292e35',3);L(c,[-4,-16,7,-15],LB.ink,2);L(c,[-28,-20,-21,-8],'#fff4d2',1.5)}if(a.accessory===2){L(c,[-35,-36,31,1],LB.ink,3);P(c,'M5-23 Q20-29 30-15 L26-3 Q7 4 5-23Z','#34323a')}if(a.accessory===3)P(c,'M-36-34 Q0-43 33-30 L34-23 Q-3-32-36-25Z','#bb4d45');if(a.accessory===4){P(c,'M-38-37 L-33-64 Q-6-74 24-62 L29-39 47-34 Q27-24-15-30 L-44-31Z','#9a8060');P(c,'M-34-47 Q0-55 28-44 L29-37 Q-4-45-36-39Z','#5d655d',null)}if(a.accessory===7){c.save();c.translate(23,-33);c.rotate(.4);P(c,'M-12-4 L12-4 12 4-12 4Z','#e9d3a3',LB.ink,1);L(c,[-3,-3,-3,3,3,3,3,-3],'#b39d77',1);c.restore()}if(injury>.25){P(c,'M-30-1 Q-22-8-13 0 L-15 8-28 7Z','#8f607066',null);P(c,'M20-35 L25-28 21-21',null,'#9b4a3d',2);if(injury>.65)P(c,'M-15 16 L-19 23-17 32',null,'#963b36',2)}c.restore()};
})();
