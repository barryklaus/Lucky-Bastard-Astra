'use strict';
LB.Physics={projectiles:[],parts:[],reset(){this.projectiles=[];this.parts=[]},throwWeapon(f){if(!f.weapon)return;const h=LB.Rig.contact(f,LB.game.time),enemy=f.opponent;this.projectiles.push({type:'weapon',id:f.weapon,owner:f,x:h.x,y:h.y,vx:(enemy.x-h.x)/.55,vy:-140,angle:1,spin:12*f.facing,life:22,bounce:0,hit:false});f.lastWeapon=f.weapon;f.weapon=0;LB.Audio.tone(300,.2,.04,'sawtooth',90)},detach(f,type='head',pose){
 if(type==='torso')type='upperBody';
 if(!['head','upperBody','frontArm','rearArm','frontLeg','rearLeg'].includes(type))throw Error('Unknown detached part: '+type);
 if((type==='head'&&f.headDetached)||(type==='upperBody'&&f.upperDetached)||f.detached?.[type])return;
 if(this.parts.length>=12)this.parts.shift();
 const sourcePose=pose||LB.Animation.pose(f,LB.game.time);
 const frozen=JSON.parse(JSON.stringify(sourcePose));frozen.face='unconscious';frozen.hand='limp';
 const geometry=LB.Finishers.geometry(f,type,frozen),mid=LB.game.fighters.length?LB.game.fighters.reduce((sum,v)=>sum+v.x,0)/LB.game.fighters.length:f.x;
 const rig={appearance:{...f.appearance},poseOverride:frozen,x:0,y:0,facing:f.facing,scale:f.scale,hp:0,maxHp:f.maxHp,stamina:0,state:'defeat',physicsRotation:f.physicsRotation||0,weapon:type==='frontArm'||type==='upperBody'?f.weapon:0,detached:{},headDetached:false,upperDetached:false};
 this.parts.push({type,appearance:rig.appearance,rig,anchor:geometry.anchor,points:geometry.points,x:f.x+geometry.anchor.x,y:f.y+geometry.anchor.y,vx:LB.clamp((mid-f.x)*.6,-120,120)+LB.rand(-30,30),vy:type==='head'?-265:-185,angle:0,spin:LB.rand(-5,5),life:40,bounce:0,settled:false});
 if(type==='head')f.headDetached=true;else if(type==='upperBody')f.upperDetached=true;else{f.detached=f.detached||{};f.detached[type]=true}
 if(type==='frontArm'||type==='upperBody')f.weapon=0;
 LB.Particles.blood(f.x+geometry.anchor.x,f.y+geometry.anchor.y,18,f.facing);
},update(dt){for(let i=this.projectiles.length-1;i>=0;i--){const p=this.projectiles[i];p.life-=dt;if(p.bounce<3){const oldX=p.x,oldY=p.y;p.vy+=500*dt;p.x+=p.vx*dt;p.y+=p.vy*dt;p.angle+=p.spin*dt;if(!p.hit){const targets=p.type==='weapon'?[p.owner.opponent]:[p.target];for(const f of targets){if(!f||f.hp<=0)continue;const b=LB.bodySpecs[f.appearance.body],s=f.appearance.height;const top=f.y-(b.leg+b.torso+80)*s;const dx=p.x-f.x;if(Math.abs(dx)<b.w*s+23&&p.y>top&&p.y<f.y-28){p.hit=true;if(p.type==='weapon'){LB.Combat.damage(p.owner,f,LB.weaponById(p.id).damage*(1+LB.abilityValue(p.owner,'throw')),p.x,p.y,{kind:'weapon',thrown:true});p.vx*=-.3;p.vy=-100}else{f.stamina=Math.max(0,f.stamina-14);f.gainPopularity(-5);if(!LB.game.finalHold&&!['grapple','grappled','lifted','carried','thrown'].includes(f.state)){f.state='stunned';f.action=null;f.hitTimer=.65}LB.Particles.burst(p.x,p.y,9,'#bd5542','trash');p.life=0}break}}}if(p.y>LB.FLOOR){p.y=LB.FLOOR;p.vy=-Math.abs(p.vy)*.38;p.vx*=.62;p.spin*=.55;p.bounce++;if(Math.abs(p.vy)<25)p.bounce=3}p.x=LB.clamp(p.x,30,2370)}else{p.vx=0;p.spin=0;if(p.type==='weapon'&&Math.random()<dt*.8){for(const f of LB.game.fighters){if(!f.weapon&&f.hp>0&&!f.action&&Math.abs(f.x-p.x)<65&&Math.random()<.4+LB.abilityValue(f,'pickup')){f.weapon=p.id;f.state='pickup';f.action={kind:'pickup',time:0,duration:.75,impact:2};p.life=0;LB.Particles.word(f.x,f.y-270,'FINDERS KEEPERS','#d8e9a2');break}}}}if(p.life<=0)this.projectiles.splice(i,1)}
for(const p of this.parts){
 p.life-=dt;if(p.settled)continue;
 p.vy+=700*dt;p.x+=p.vx*dt;p.y+=p.vy*dt;p.angle+=p.spin*dt;
 const bottom=Math.max(...p.points.map(q=>q.x*Math.sin(p.angle)+q.y*Math.cos(p.angle)+q.r));
 if(p.y+bottom>=LB.FLOOR){p.y=LB.FLOOR-bottom;p.vy=-Math.abs(p.vy)*.37;p.vx*=.64;p.spin*=.55;p.bounce++;
  if(!LB.settings.reducedGore)LB.Particles.stain(p.x,LB.FLOOR,p.type==='upperBody'?35:16);
  if(p.bounce>=5||Math.abs(p.vy)<22){p.vy=0;p.vx=0;p.spin=0;p.settled=true}
 }
 p.x=LB.clamp(p.x,70,2330);
}this.parts=this.parts.filter(p=>p.life>0);
for(const f of LB.game.fighters){if(f.state==='thrown'){f.x+=f.vx*dt;f.y+=f.vy*dt;f.vy+=680*dt;f.physicsRotation+=f.spin*dt;if(f.y>=LB.FLOOR){f.y=LB.FLOOR;f.state=f.hp<=0?'defeat':'knockdown';f.fallProgress=1;f.physicsRotation=0;f.hitTimer=1.4;LB.Particles.burst(f.x,LB.FLOOR,18,'#c5b68b','dust');LB.Camera.shake=6;LB.Arena.breakNear(f.x,30)}}else if(['fall','defeat','knockdown','unconscious'].includes(f.state)){f.fallProgress=Math.min(1,f.fallProgress+dt*2.6);f.x+=f.vx*dt;f.vx*=Math.exp(-dt*6);if(f.hp<=0)f.state='defeat'}f.x=LB.clamp(f.x,190,2210)}} ,draw(c){for(const p of this.projectiles){c.save();c.translate(p.x,p.y);c.rotate(p.angle);if(p.type==='weapon')LB.drawWeapon(c,p.id);else{LB.path(c,'M-8-3 Q-9-11 0-9 Q10-11 11-2 Q14 9 3 11 Q-9 12-8-3Z','#bb5542',LB.ink,1.8);LB.path(c,'M-3-8 L0-13 3-9 8-12 6-6Z','#727d45',LB.ink,1)}c.restore()}for(const p of this.parts)LB.Finishers.drawPart(c,p)}};
